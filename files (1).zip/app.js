const cart = [];

function addToCart(product, price) {
  cart.push({ product, price });
  updateCart();
}

function updateCart() {
  const cartItems = document.getElementById('cart-items');
  cartItems.innerHTML = '';
  let total = 0;

  cart.forEach(item => {
    total += item.price;
    const div = document.createElement('div');
    div.classList.add('cart-item');
    div.textContent = `${item.product} - $${item.price.toFixed(2)}`;
    cartItems.appendChild(div);
  });

  document.getElementById('total').textContent = `Total: $${total.toFixed(2)}`;
}

document.getElementById('payment-form').addEventListener('submit', function(event) {
  event.preventDefault();
  alert('Payment processed successfully! Thank you for your purchase.');
});